#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
   return -1;
  //myproc()->sz = addr + n;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int sys_get_va_to_pa(void){

  int n;
  char * ch;
  uint * pa;
  int size = 4;
  int * flag;
  
  if(argint(0, &n) < 0) return 0;

  argptr(1, &ch, size);

  pa = (uint *) ch;

  argptr(2, &ch, size);

  flag = (int *) ch;
  // if(argptr(2, ch, size) < 0) return 0;

  // flag = (int *) ch;
  //if(argptr(2, flag) < 0) return 0;

  uint va = n;
 

  struct proc *curproc = myproc();
  
  int alloc = 0;

  pde_t* pgdir = curproc->pgdir ;

  pde_t *pde;
  pte_t *pgtab ;

  pde = &pgdir[PDX(va)];
  if(*pde & PTE_P){
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
  } else {
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0){
      //printf(1,"VA: 0x%x   PA: no mapping \n", va);
      return 0;
    }
   // Make sure all those PTE_P bits are zero.
    memset(pgtab, 0, PGSIZE);
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }

  uint x = pgtab[PTX(va)];

  x = x >> 12;

  x = x << 12;

  uint y = pgtab[PTX(va)];

  y = y << 20;
  y = y >> 20;

  va = va << 20;
  va = va >> 20;

  *pa = va + x;

  *flag = y;

  y = y & 0x00000001;

  if(y == 0){return 0;} 

  //printf(1,"VA: 0x%x   PA: 0x%x \n", va1, va+x);
  return 1;

}

int sys_get_mem(void){
  struct proc *curproc = myproc();
  return curproc->sz;
}
