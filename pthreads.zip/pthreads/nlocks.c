#include <pthread.h>
#include <stdio.h>

#define NTHREADS 10

static pthread_mutex_t mutex[NTHREADS]; 

void init_locks(){
	for(int i=0;i<NTHREADS;i++){
		pthread_mutex_init ( &mutex[i], NULL);
	}
}

long int counter[10];

typedef struct __arguments {
 int index;
	} arguments;


void *myThread(void * args)
{
	for(int i=0; i<1000; i++){
		arguments * a = (arguments *) args;  
		pthread_mutex_lock( &mutex[a->index] );
		counter[a->index]+=1;
		pthread_mutex_unlock( &mutex[a->index] );
		}
}

int main()
{

	init_locks();

	arguments args[10];

	for(int i=0;i<10;i++) counter[i]=0;

	for(int i=0;i<10;i++) args[i].index=i;

	pthread_t tid[NTHREADS];

	for(int i=0; i<NTHREADS; i++)
	{
		pthread_create(&tid[i], NULL, myThread, &args[i]);
	}

	for(int j=0;j<1000;j++){
		for(int i=0;i<NTHREADS;i++){
			pthread_mutex_lock( &mutex[i] );
			counter[i]+=1;
			pthread_mutex_unlock( &mutex[i] );
		}
	}

	for(int i=0; i<NTHREADS; i++)
	{
		//	Wait for all threads to finish
		pthread_join(tid[i], NULL);
	}

	for(int i=0; i<NTHREADS; i++)
	pthread_mutex_destroy( &mutex[i] );

	for(int i=0;i<NTHREADS;i++)
	printf("Counter[%d]: %ld \n",i, counter[i]);

	return 0;
}
