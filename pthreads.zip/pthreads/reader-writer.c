#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <time.h>


struct read_write_lock
{
	// If required, use this strucure to create
	// reader-writer lock related variables
	int readers;
	int writers;
	int waiting;
	pthread_mutex_t lock;

}rw;


typedef struct __arguments {
 int index;
 int delay;
	} arguments;

pthread_cond_t reader_cond = PTHREAD_COND_INITIALIZER;
pthread_cond_t writer_cond = PTHREAD_COND_INITIALIZER;

long int data = 0;			//	Shared data variable

void InitalizeReadWriteLock(struct read_write_lock * rw)
{
	rw->readers = 0;
	rw->writers = 0;
	rw->waiting = 0;
	pthread_mutex_init ( &rw->lock, NULL);
}


// The pthread based reader lock
void ReaderLock(struct read_write_lock * rw)
{
	pthread_mutex_lock( &rw->lock);
	while(rw->writers > 0 || rw->waiting > 0) pthread_cond_wait(&reader_cond,&rw->lock);
	rw->readers+=1;
	pthread_mutex_unlock( &rw->lock);
}	

// The pthread based reader unlock
void ReaderUnlock(struct read_write_lock * rw)
{
	pthread_mutex_lock( &rw->lock);
	rw->readers-=1;
	if(rw->readers == 0) pthread_cond_broadcast(&writer_cond);
	pthread_mutex_unlock( &rw->lock);
}

// The pthread based writer lock
void WriterLock(struct read_write_lock * rw)
{
	pthread_mutex_lock( &rw->lock);
	rw->waiting+=1;
	while(rw->writers > 0 || rw->readers > 0) pthread_cond_wait(&writer_cond,&rw->lock);
	rw->waiting-=1;
	rw->writers+=1;
	pthread_mutex_unlock( &rw->lock);
}

// The pthread based writer unlock
void WriterUnlock(struct read_write_lock * rw)
{
	pthread_mutex_lock( &rw->lock);
	rw->writers-=1;
	if(rw->writers==0){
		pthread_cond_signal(&writer_cond);
		if(rw->writers == 0)pthread_cond_broadcast(&reader_cond);
	}
	pthread_mutex_unlock( &rw->lock);
}

//	Call this function to delay the execution by 'delay' ms
void delay(int delay)
{
	struct timespec wait;

	if(delay <= 0)
		return;

	wait.tv_sec = delay / 1000;
	wait.tv_nsec = (delay % 1000) * 1000 * 1000;
	nanosleep(&wait, NULL);
}

// The pthread reader start function
void *ReaderFunction(void *args)
{
	//	Delay the execution by arrival time specified in the input
	arguments * arg = (arguments *) args;
	//delay(arg->delay);
	//	....
	ReaderLock(&rw);
	
	printf("	Reader %d, data: %ld\n",arg->index, data);
	//delay(1);
	ReaderUnlock(&rw);
    //  Add a dummy delay of 1 ms before lock release  
	//	....
}

// The pthread writer start function
void *WriterFunction(void *args)
{
	//	Delay the execution by arrival time specified in the input
	arguments * arg = (arguments *) args;
	//delay(arg->delay);
	//	....
	WriterLock(&rw);
	data+=1;
	printf("Writer  %d, data: %ld\n",arg->index, data);
	//delay(1);
    WriterUnlock(&rw);
   
}

int main(int argc, char *argv[])
{
	pthread_t *threads;
	
	long int reader_number = 1;
	long int writer_number = 1;
	long int thread_number = 0;
	long int total_threads = 0;	
	
	int count = 0;			// Number of 3 tuples in the inputs.	Assume maximum 10 tuples 
	int rws[10];			
	int nthread[10];
	int delay[10];

	InitalizeReadWriteLock(&rw);

	//	Verifying number of arguments
	if(argc<4 || (argc-1)%3!=0)
	{
		printf("reader-writer <r/w> <no-of-threads> <thread-arrival-delay in ms> ...\n");		
		printf("Any number of readers/writers can be added with repetitions of above mentioned 3 tuple \n");
		exit(1);
	}

	//	Reading inputs
	for(int i=0; i<(argc-1)/3; i++)
	{
		char rw[2];
		strcpy(rw, argv[(i*3)+1]);

		if(strcmp(rw, "r") == 0 || strcmp(rw, "w") == 0)
		{
			if(strcmp(rw, "r") == 0)
				rws[i] = 1;					// rws[i] = 1, for reader
			else
				rws[i] = 2;					// rws[i] = 2, for writer
			
			nthread[i] = atol(argv[(i*3)+2]);		
			delay[i] = atol(argv[(i*3)+3]);

			count ++;						//	Number of tuples
			total_threads += nthread[i];	//	Total number of threads
		}
		else
		{
			printf("reader-writer <r/w> <no-of-threads> <thread-arrival-delay in ms> ...\n");
			printf("Any number of readers/writers can be added with repetitions of above mentioned 3 tuple \n");
			exit(1);
		}
	}

	arguments args[total_threads];

	int start = 0;
	int rws2[total_threads];

	for(int i=0;i<(argc-1)/3;i++){
		if(rws[i]==1){
			for(int j=0;j<nthread[i];j++){
			rws2[start]=1;
			args[start].index = reader_number;
			reader_number++;
			start++;
			args[i].delay = delay[i]+0;
			//printf("%d\n", delay[i]);
			}
		}
		else{
			for(int j=0;j<nthread[i];j++){
			rws2[start]=2;
			args[start].index = writer_number;
			writer_number++;
			start++;
			args[i].delay = delay[i]+0;
			//printf("%d\n", delay[i]);
			}
		}
		
	}

	pthread_t tid[total_threads];

	//for (int i = 0; i < total_threads; i++) printf("%d\n", args[i].delay);

	for (int i = 0; i < total_threads; i++)
	{
		if(rws2[i]==1){
			pthread_create(&tid[i], NULL, ReaderFunction, &args[i]);
		}
		else{
			pthread_create(&tid[i], NULL, WriterFunction, &args[i]);
		}
	}

	for(int i=0; i<total_threads; i++)
	{
		pthread_join(tid[i], NULL);
	}

	//	Create reader/writer threads based on the input and read and write.

	//  Clean up threads on exit

	exit(0);
}
