#include "types.h"
#include "stat.h"
#include "user.h"

void mutex_lock(int index)
{
	acquire_mutex_spinlock(index);
	while(get_mutex_value(index)) cond_wait(index,index);
	set_mutex_value(index,1);
	release_mutex_spinlock(index);
}

void mutex_unlock(int index)
{
	/*
		Todo
	*/
	acquire_mutex_spinlock(index);
	set_mutex_value(index,0);
	cond_signal(index);
	release_mutex_spinlock(index);	
}

int main()
{
	int ret;
	int i;


	init_counters();

	for(int k=0;k<10;k++){
	ret = fork();
	if(ret == 0)
	{
		for(i=0; i<10000; i++)
		{
		mutex_lock(k);
		set_var(k, get_var(k)+1);
		mutex_unlock(k);
		}
		exit();
	}		
	}

	
	for(int k=0;k<10;k++){
	for(i=0; i<10000; i++)
	{
		mutex_lock(k);
		set_var(k, get_var(k)+1);
		mutex_unlock(k);
	}
}
	

	
	
		for(int k=0;k<10;k++) wait();
		for(int k=0;k<10;k++){
		int val = get_var(k);
		printf(1, "data[%d] = %d\n",k, val);
		}

		exit();
	
}

